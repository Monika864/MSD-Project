import React, { useState } from "react";
import "../styles/auth.css";

const Signup = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSignup = (e) => {
    e.preventDefault();
    // Store user details in localStorage
    localStorage.setItem("userFirstName", firstName);
    localStorage.setItem("userLastName", lastName);
    localStorage.setItem("userEmail", email);
    localStorage.setItem("userPassword", password);

    alert("Signup successful! Now login with your details.");
    window.location.href = "/login"; // Redirect to login page
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h2>DocAssist - Signup</h2>
        <form onSubmit={handleSignup} className="auth-form">
          <input
            type="text"
            placeholder="First Name"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Last Name"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            required
          />
          <input
            type="email"
            placeholder="Enter Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit" className="auth-btn">Signup</button>
        </form>

        {/* Sign In link */}
        <p className="signin-text">
          Already have an account?{" "}
          <a href="/login" className="signin-link">Sign In</a>
        </p>
      </div>
    </div>
  );
};

export default Signup;
