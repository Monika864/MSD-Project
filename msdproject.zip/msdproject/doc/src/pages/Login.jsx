import React, { useState } from "react";
import "../styles/auth.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    const storedEmail = localStorage.getItem("userEmail");
    const storedPassword = localStorage.getItem("userPassword");

    if (email === storedEmail && password === storedPassword) {
      alert("Login successful!");
      window.location.href = "/dashboard";
    } else {
      alert("Invalid credentials! Please try again.");
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        {/* Heading Updated */}
        <h2>DocAssist Login</h2>

        <form onSubmit={handleLogin} className="auth-form">
          <input
            type="email"
            placeholder="Enter Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button type="submit" className="auth-btn">Login</button>
        </form>

        {/* Sign Up Link Below */}
        <p className="signup-link">
          Don’t have an account?{" "}
          <a href="/signup">Sign Up</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
