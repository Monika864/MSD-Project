import React from "react";
import { Link } from "react-router-dom";
import "../styles/globals.css";

const Home = () => {
  return (
    <div className="home-container">
      <header className="home-header">
        <h1>Welcome to DocAssist</h1>
        <p>A unified platform for accessing government schemes & services</p>
      </header>

      <div className="home-actions">
        <Link to="/login" className="btn-primary">Login</Link>
        <Link to="/signup" className="btn-secondary">Sign Up</Link>
      </div>
    </div>
  );
};

export default Home;
