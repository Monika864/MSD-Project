import React, { useState } from "react";
import "../styles/dashboard.css";
import LocationMap from "../components/LocationMap";

const sections = [
  { key: "overview", label: "Dashboard Overview" },
  { key: "documents", label: "Document Management" },
  { key: "schemes", label: "Schemes & Applications" },
  { key: "ai", label: "AI Assistant" },
  { key: "location", label: "Location-Based Services" },
  { key: "alerts", label: "Alerts & Feedback" },
];

const Dashboard = () => {
  const [activeSection, setActiveSection] = useState("overview");

  return (
    <div className="dashboard-container">
      {/* Top Navbar */}
      <header className="dashboard-navbar">
        <div className="navbar-left">
          <h1>DocAssist</h1>
        </div>
        <nav className="navbar-right">
          <a href="#profile">Profile</a>
          <a href="#language">🌐 Language</a>
          <a href="#logout">Logout</a>
        </nav>
      </header>

      <div className="dashboard-body">
        {/* Sidebar */}
        <aside className="dashboard-sidenav">
          <nav>
            {sections.map((section) => (
              <button
                key={section.key}
                className="sidenav-btn"
                onClick={() => setActiveSection(section.key)}
              >
                {section.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="dashboard-main">
          {activeSection === "overview" && (
            <section className="dashboard-section">
              <h2>Dashboard Overview</h2>
              <div className="dashboard-row">
                <div className="dashboard-card">
                  <h3>Ongoing Applications</h3>
                  <p>View status of car, land, and other government applications.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Upcoming Deadlines</h3>
                  <p>Get reminders for renewals and document submissions.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Suggestions</h3>
                  <p>Personalized tips and recommended schemes for you.</p>
                </div>
              </div>
            </section>
          )}

          {activeSection === "documents" && (
            <section className="dashboard-section">
              <h2>Document Management</h2>
              <div className="dashboard-row">
                <div className="dashboard-card">
                  <h3>Upload Documents</h3>
                  <p>Upload and verify personal and family documents.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Secure Storage</h3>
                  <p>Encrypted storage with access control.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Family Docs</h3>
                  <p>Store family members’ documents in your profile.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Eligibility Check</h3>
                  <p>Check eligibility for schemes/services based on documents.</p>
                </div>
              </div>
            </section>
          )}

          {activeSection === "schemes" && (
            <section className="dashboard-section">
              <h2>Schemes & Applications</h2>
              <div className="dashboard-row">
                <div className="dashboard-card">
                  <h3>Scheme Details</h3>
                  <p>Browse government schemes with eligibility info.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Application Status</h3>
                  <p>Track status of car, land, and other applications.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Download Certificates</h3>
                  <p>Download official PDFs and e-certificates.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Media Uploads</h3>
                  <p>Upload images, PDFs, or videos for claims/disputes.</p>
                </div>
              </div>
            </section>
          )}

          {activeSection === "ai" && (
            <section className="dashboard-section">
              <h2>AI Assistant</h2>
              <div className="dashboard-row">
                <div className="dashboard-card">
                  <h3>Chat Assistant</h3>
                  <p>Ask about schemes, eligibility, and documentation.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Form Guidance</h3>
                  <p>Get step-by-step help for forms and FAQs.</p>
                </div>
              </div>
            </section>
          )}

          {activeSection === "location" && (
            <section className="dashboard-section">
              <h2>Location-Based Services</h2>
              <div className="dashboard-row">
                <div className="dashboard-card" style={{ flex: "1 1 100%" }}>
                  <LocationMap />
                  <p style={{ marginTop: "1rem" }}>
                    Find government centers, banks, and service points near you.
                  </p>
                </div>
              </div>
            </section>
          )}

          {activeSection === "alerts" && (
            <section className="dashboard-section">
              <h2>Alerts & Feedback</h2>
              <div className="dashboard-row">
                <div className="dashboard-card">
                  <h3>Alerts</h3>
                  <p>Get notified about updates, deadlines, and approvals.</p>
                </div>
                <div className="dashboard-card">
                  <h3>Feedback</h3>
                  <p>Share feedback for transparency and improvement.</p>
                </div>
              </div>
            </section>
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="dashboard-footer">
        © 2025 DocAssist | Secure & Real-Time Government Services
      </footer>
    </div>
  );
};

export default Dashboard;