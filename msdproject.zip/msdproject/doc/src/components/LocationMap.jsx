import React, { useEffect, useRef, useState } from "react";

const LocationMap = () => {
  const mapRef = useRef(null);
  const [userLocation, setUserLocation] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [distance, setDistance] = useState("");
  const [searchedPlace, setSearchedPlace] = useState("");
  const [mapInstance, setMapInstance] = useState(null);
  const [inputError, setInputError] = useState("");

  useEffect(() => {
    if (!window.google || !window.google.maps.places) return;

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const loc = { lat: latitude, lng: longitude };
        setUserLocation(loc);

        const map = new window.google.maps.Map(mapRef.current, {
          center: loc,
          zoom: 14,
        });
        setMapInstance(map);

        // User marker
        new window.google.maps.Marker({
          position: loc,
          map,
          title: "Your Location",
          icon: {
            url: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png"
          }
        });

        // Place types to search for
        const placeTypes = [
          "bank",
          "atm",
          "local_government_office",
          "post_office"
        ];

        const service = new window.google.maps.places.PlacesService(map);

        placeTypes.forEach(type => {
          service.nearbySearch(
            {
              location: loc,
              radius: 10000,
              type: type
            },
            (results, status) => {
              if (
                status === window.google.maps.places.PlacesServiceStatus.OK &&
                results
              ) {
                results.forEach(place => {
                  new window.google.maps.Marker({
                    position: place.geometry.location,
                    map,
                    title: place.name,
                    icon: {
                      url: "http://maps.google.com/mapfiles/ms/icons/red-dot.png"
                    }
                  });
                });
              }
            }
          );
        });
      },
      () => {
        const defaultLocation = { lat: 20.5937, lng: 78.9629 };
        setUserLocation(defaultLocation);
        const map = new window.google.maps.Map(mapRef.current, {
          center: defaultLocation,
          zoom: 5,
        });
        setMapInstance(map);
      }
    );
  }, []);

  // Search handler using Geocoding API for location names
  const handleSearch = () => {
    setDistance("");
    setSearchedPlace("");
    setInputError("");
    if (!window.google || !userLocation || !searchTerm) return;

    if (searchTerm.trim().length < 3) {
      setInputError("Please enter at least 3 characters for search.");
      return;
    }

    const map = mapInstance || new window.google.maps.Map(mapRef.current, {
      center: userLocation,
      zoom: 14,
    });

    // User marker
    new window.google.maps.Marker({
      position: userLocation,
      map,
      title: "Your Location",
      icon: {
        url: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png"
      }
    });

    // Nearby places as before
    const placeTypes = [
      "bank",
      "atm",
      "local_government_office",
      "post_office"
    ];
    const service = new window.google.maps.places.PlacesService(map);
    placeTypes.forEach(type => {
      service.nearbySearch(
        {
          location: userLocation,
          radius: 10000,
          type: type
        },
        (results, status) => {
          if (
            status === window.google.maps.places.PlacesServiceStatus.OK &&
            results
          ) {
            results.forEach(place => {
              new window.google.maps.Marker({
                position: place.geometry.location,
                map,
                title: place.name,
                icon: {
                  url: "http://maps.google.com/mapfiles/ms/icons/red-dot.png"
                }
              });
            });
          }
        }
      );
    });

    // Geocode the search term (city/town/area)
    const geocoder = new window.google.maps.Geocoder();
    geocoder.geocode({ address: searchTerm }, (results, status) => {
      if (status === "OK" && results && results.length > 0) {
        const place = results[0];
        setSearchedPlace(place.formatted_address);

        // Place green marker at the found location
        new window.google.maps.Marker({
          position: place.geometry.location,
          map,
          title: place.formatted_address,
          icon: {
            url: "http://maps.google.com/mapfiles/ms/icons/green-dot.png"
          }
        });

        map.setCenter(place.geometry.location);
        map.setZoom(13);

        // Calculate distance
        const userLatLng = new window.google.maps.LatLng(userLocation.lat, userLocation.lng);
        const placeLatLng = place.geometry.location;
        const dist =
          window.google.maps.geometry
            ? window.google.maps.geometry.spherical.computeDistanceBetween(userLatLng, placeLatLng)
            : null;
        if (dist !== null) {
          setDistance((dist / 1000).toFixed(2)); // in km
        } else {
          setDistance("N/A");
        }
      } else {
        setDistance("");
        setSearchedPlace("");
        setInputError("No matching place found (make sure the name is correct and present in Google Maps)");
      }
    });
  };

  return (
    <div>
      <h3>Nearby Centers</h3>
      <div style={{ marginBottom: "1rem" }}>
        <input
          type="text"
          placeholder="Search for a place, city, or area..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          style={{
            padding: "0.5rem",
            borderRadius: "6px",
            border: "1px solid #ccc",
            width: "60%",
            marginRight: "0.5rem"
          }}
        />
        <button
          onClick={handleSearch}
          style={{
            padding: "0.5rem 1rem",
            borderRadius: "6px",
            border: "none",
            background: "#2563eb",
            color: "#fff",
            fontWeight: "600",
            cursor: "pointer"
          }}
        >
          Search
        </button>
        {inputError && (
          <div style={{ marginTop: "0.7rem", color: "#d32f2f", fontWeight: "500" }}>
            {inputError}
          </div>
        )}
        {distance && searchedPlace && (
          <div style={{ marginTop: "0.7rem", color: "#2563eb", fontWeight: "500" }}>
            Distance to "{searchedPlace}": {distance} km
          </div>
        )}
      </div>
      <div
        ref={mapRef}
        style={{
          width: "100%",
          height: "350px",
          borderRadius: "12px",
          boxShadow: "0 2px 12px rgba(37,99,235,0.08)",
          marginTop: "1rem",
        }}
      />
    </div>
  );
};

export default LocationMap;